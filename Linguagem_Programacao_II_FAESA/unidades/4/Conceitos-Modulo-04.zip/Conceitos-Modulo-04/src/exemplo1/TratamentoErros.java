package exemplo1;

public class TratamentoErros{
	public static void main(String args[]){
		try{
			int num1 = Integer.parseInt(args[0]);
			int num2 = Integer.parseInt(args[1]);
			if (num2 == 0){
				throw new ArithmeticException("ERRO DE DIVIS�O POR ZERO");  // n�o verific�vel
			}
			else{
				System.out.println("num1/num2 = " + div(num1, num2));
			}
		}
		catch (ArithmeticException e){
			System.out.println(e.getMessage());
		}
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("N�mero de par�metros insuficiente");
		}
		catch (NumberFormatException e){
			System.out.println("Digite apenas numeros inteiros!!!");
		}
		finally {
			System.out.println("O finally sempre � executado!!!");
		}
	}
	public static int div(int n1, int n2) throws ArithmeticException {
			return n1/n2;
	}
	
}