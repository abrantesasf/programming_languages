package exemplo2;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Rectangle;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import java.awt.Point;

public class Calculadora extends JFrame implements ActionListener, KeyListener{

	private JPanel jContentPane = null;

	private JLabel jLabel_Num1 = null;

	private JLabel jLabel_Num2 = null;

	private JLabel jLabel_Total = null;

	private JTextField jTextField_Num1 = null;

	private JTextField jTextField_Num2 = null;

	private JButton jButton_Soma = null;

	private JButton jButton_Subtrai = null;

	private JButton jButton_Multiplica = null;

	private JButton jButton_Divide = null;

	private JTextField jTextField_Resultado = null;

	private JButton jButton_Limpa = null;

	private JButton jButton_Resto = null;

	/**
	 * This method initializes jTextField_Num1	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField_Num1() {
		if (jTextField_Num1 == null) {
			jTextField_Num1 = new JTextField();
			jTextField_Num1.setBackground(SystemColor.activeCaptionBorder);
			jTextField_Num1.setHorizontalAlignment(JTextField.CENTER);
		}
		return jTextField_Num1;
	}

	/**
	 * This method initializes jTextField_Num2	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField_Num2() {
		if (jTextField_Num2 == null) {
			jTextField_Num2 = new JTextField();
			jTextField_Num2.setBackground(SystemColor.activeCaptionBorder);
			jTextField_Num2.setHorizontalAlignment(JTextField.CENTER);
		}
		return jTextField_Num2;
	}

	/**
	 * This method initializes jButton_Soma	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton_Soma() {
		if (jButton_Soma == null) {
			jButton_Soma = new JButton();
			jButton_Soma.setText("+");
			jButton_Soma.setFont(new Font("Dialog", Font.BOLD, 24));
			jButton_Soma.addActionListener(this);
		}
		return jButton_Soma;
	}

	/**
	 * This method initializes jButton_Subtrai	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton_Subtrai() {
		if (jButton_Subtrai == null) {
			jButton_Subtrai = new JButton();
			jButton_Subtrai.setText("-");
			jButton_Subtrai.setFont(new Font("Dialog", Font.BOLD, 24));
			jButton_Subtrai.addActionListener(this);
		}
		return jButton_Subtrai;
	}

	/**
	 * This method initializes jButton_Multiplica	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton_Multiplica() {
		if (jButton_Multiplica == null) {
			jButton_Multiplica = new JButton();
			jButton_Multiplica.setText("*");
			jButton_Multiplica.setFont(new Font("Dialog", Font.BOLD, 24));
			jButton_Multiplica.addActionListener(this);
		}
		return jButton_Multiplica;
	}

	/**
	 * This method initializes jButton_Divide	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton_Divide() {
		if (jButton_Divide == null) {
			jButton_Divide = new JButton();
			jButton_Divide.setText("/");
			jButton_Divide.setFont(new Font("Dialog", Font.BOLD, 24));
			jButton_Divide.addActionListener(this);
		}
		return jButton_Divide;
	}

	/**
	 * This method initializes jTextField_Resultado	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField_Resultado() {
		if (jTextField_Resultado == null) {
			jTextField_Resultado = new JTextField();
			jTextField_Resultado.setBackground(SystemColor.activeCaptionBorder);
			jTextField_Resultado.setHorizontalAlignment(JTextField.CENTER);
		}
		return jTextField_Resultado;
	}

	/**
	 * This method initializes jButton_Limpa	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton_Limpa() {
		if (jButton_Limpa == null) {
			jButton_Limpa = new JButton();
			jButton_Limpa.setText("L");
			jButton_Limpa.setFont(new Font("Dialog", Font.BOLD, 24));
			jButton_Limpa.addActionListener(this);
		}
		return jButton_Limpa;
	}

	/**
	 * This method initializes jButton_Resto	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton_Resto() {
		if (jButton_Resto == null) {
			jButton_Resto = new JButton();
			jButton_Resto.setText("Resto");
			jButton_Resto.setIcon(new ImageIcon(getClass().getResource("/exemplo2/dukeTray.gif")));
			jButton_Resto.addActionListener(this);
		}
		return jButton_Resto;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculadora application = new Calculadora();
		application.show();
	}

	/**
	 * This is the default constructor
	 */
	public Calculadora() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(new Dimension(458, 276));
		this.setLocationRelativeTo(null);
		this.setContentPane(getJContentPane());
		this.setTitle("Calculadora");
		this.pack();
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			GridLayout gridLayout = new GridLayout();
			gridLayout.setRows(3);
			jLabel_Total = new JLabel();
			jLabel_Total.setText("Total");
			jLabel_Total.setHorizontalAlignment(SwingConstants.CENTER);
			jLabel_Total.setFont(new Font("Malgun Gothic", Font.BOLD | Font.ITALIC, 18));
			jLabel_Total.setEnabled(false);
			jLabel_Num2 = new JLabel();
			jLabel_Num2.setText("Num. 2");
			jLabel_Num2.setHorizontalAlignment(SwingConstants.CENTER);
			jLabel_Num2.setFont(new Font("Malgun Gothic", Font.BOLD | Font.ITALIC, 18));
			jLabel_Num2.setEnabled(false);
			jLabel_Num1 = new JLabel();
			jLabel_Num1.setText("Num. 1");
			jLabel_Num1.setHorizontalAlignment(SwingConstants.CENTER);
			jLabel_Num1.setFont(new Font("Malgun Gothic", Font.BOLD | Font.ITALIC, 18));
			jLabel_Num1.setEnabled(false);
			jContentPane = new JPanel();
			jContentPane.setLayout(gridLayout);
			jContentPane.add(jLabel_Num1, null);
			jContentPane.add(getJTextField_Num1(), null);
			jContentPane.add(getJButton_Soma(), null);
			jContentPane.add(getJButton_Subtrai(), null);
			jContentPane.add(jLabel_Num2, null);
			jContentPane.add(getJTextField_Num2(), null);
			jContentPane.add(getJButton_Multiplica(), null);
			jContentPane.add(getJButton_Divide(), null);
			jContentPane.add(jLabel_Total, null);
			jContentPane.add(getJTextField_Resultado(), null);
			jContentPane.add(getJButton_Limpa(), null);
			jContentPane.add(getJButton_Resto(), null);
		}
		return jContentPane;
	}

//*
  	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		// limpa campos
		if (e.getSource()==jButton_Limpa){
			jTextField_Num1.setText("");
			jTextField_Num2.setText("");
			jTextField_Resultado.setText("");
			return;
		}
		float N1=0,N2=0,result=0;
		// trata entrada de dados (divisor nulo)		
		N1 = Float.parseFloat(jTextField_Num1.getText());
		N2 = Float.parseFloat(jTextField_Num2.getText());
		if (N2==0){
			jTextField_Resultado.setText("Erro!");
			JOptionPane.showMessageDialog(null, "Divis�o por ZERO", "ERRO", JOptionPane.ERROR_MESSAGE);
			// lance uma exce��o aqui
		}
		// tratar erro de entrada n�o num�rica
			
		// processa opera��es
		if (e.getSource()==jButton_Soma) {
			result = N1 + N2;
			System.out.println("Botao +");
		}
		if (e.getSource()==this.jButton_Subtrai) {
			result = N1 - N2;
			System.out.println("Botao -");
		}
		if (e.getSource()==this.jButton_Multiplica) {
			result = N1 * N2;
			System.out.println("Botao x");
		}
		if (e.getSource()==this.jButton_Divide) {
			result = N1 / N2;
			System.out.println("Botao /");
		}
		this.jTextField_Resultado.setText(""+result);		
	}

	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource()==this.jTextField_Num1){
			System.out.println("Digitei "+this.jTextField_Num1.getText());
		}
	}

	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
//*/
}  //  @jve:decl-index=0:visual-constraint="10,10"
