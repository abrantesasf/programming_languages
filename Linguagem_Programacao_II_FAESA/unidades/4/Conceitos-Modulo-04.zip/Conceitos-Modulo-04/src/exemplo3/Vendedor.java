package exemplo3;

public final class Vendedor extends Funcionario {
	String ctps;
	String matricula;
	
	
	public String getCtps() {
		return ctps;
	}
	public Vendedor() {
		// TODO Auto-generated constructor stub
	}
	public Vendedor(String nome, String cpf, double salario, String ctps,
			String matricula) {
		super(nome, cpf, salario);
		this.ctps = ctps;
		this.matricula = matricula;
	}
	public void setCtps(String ctps) {
		this.ctps = ctps;
	}
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	@Override
	public double calculaSalario() {
		// TODO Auto-generated method stub
		return super.calculaSalario();
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString()+
			   "\nctps: "+ctps+
			   "\nmatricula: "+matricula;
	}
}
