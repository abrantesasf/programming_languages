package exemplo3;

public abstract class Funcionario {
	String nome;
	String cpf;
	double salario;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	
	public double calculaSalario() {
		// TODO Auto-generated method stub
		return this.salario;

	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "nome: "+nome+
			   "\ncpf: "+cpf+
			   "\nsalario: "+salario;		
	}
	public Funcionario() {
		// TODO Auto-generated constructor stub
	}
	public Funcionario(String nome, String cpf, double salario) {
		super();
		this.nome = nome;
		this.cpf = cpf;
		this.salario = salario;
	}
	
}
