package exemplo3;

public class ContratoVendedor {
	Vendedor vendedor;
	/**
	 * @param args
	 */

	public static void main(String[] args) {
		ContratoVendedor cv = new ContratoVendedor();
		cv.vendedor = new Vendedor("Tiago", "031.207.665-32", 1000.0, "CT-0212", "NA0044");
		System.out.println(cv.toString());
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return vendedor.toString();
	}
	
}
