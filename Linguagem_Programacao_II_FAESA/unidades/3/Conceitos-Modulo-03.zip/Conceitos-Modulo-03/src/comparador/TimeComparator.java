/* 
 * Adapta��o do fonte TimeComparator.java
 * Fonte: Java Como programar 6a Edi��o (Deitel & Deitel)
 * Fig. 19.10: TimeComparator.java 
 */

// Classe Comparator personalizada que compara dois objetos Time.

package comparador;

import java.util.Comparator;

public class TimeComparator implements Comparator <Time> {
   public int compare(Time time1, Time time2) {
      int hourCompare = time1.getHour() - time2.getHour(); // compara hora 
         
      // testa a primeira hora 
      if ( hourCompare != 0 )
         return hourCompare;
         
      int minuteCompare = 
         time1.getMinute() - time2.getMinute(); // compara minuto 
         
      // ent�o testa o minuto
      if ( minuteCompare != 0 )
         return minuteCompare;
         
      int secondCompare = 
         time1.getSecond() - time2.getSecond(); // compara segundo 

      return secondCompare; // retorna o resultado da compara��o de segundos
   } // fim do m�todo compare
} // fim da classe TimeComparator 
