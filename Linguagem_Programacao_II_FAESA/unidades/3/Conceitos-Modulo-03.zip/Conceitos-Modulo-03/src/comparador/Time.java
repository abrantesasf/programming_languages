/* 
 * Adapta��o do fonte Time2.java
 * Fonte: Java Como programar 6a Edi��o (Deitel & Deitel)
 * Fig. 8.5: Time2.java 
 */

package comparador;

public class Time {
   private int hour;   // 0 - 23
   private int minute; // 0 - 59
   private int second; // 0 - 59

   // construtor sem argumento Time : inicializa cada vari�vel de inst�ncia
   // com zero; assegura que objetos Time iniciam em um estado consistente
   public Time() {                                                                   
      this( 0, 0, 0 ); // invoca o construtor Time com tr�s argumentos
   } // fim do construtor sem argumento Time

   // Construtor Time: hora fornecida, minuto e segundo padronizados para 0
   public Time( int h ) {                                                                    
      this( h, 0, 0 ); // invoca o construtor Time com tr�s argumentos
   } // fim do construtor de um argumento Time

   // Construtor Time: hora e minuto fornecidos, segundo padronizado para 0
   public Time( int h, int m ) {                                                                    
      this( h, m, 0 ); // invoca o construtor Time com tr�s argumentos
   } // fim do construtor de dois argumentos Time

   // Construtor Time: hour, minute e second fornecidos
   public Time( int h, int m, int s ) {                                                        
      setTime( h, m, s ); // invoca setTime para validar a data/hora
   } // fim do construtor de tr�s argumentos Time

   // Construtor Time: outro objeto Time fornecido
   public Time( Time time ) {                                                             
      // invoca o construtor de tr�s argumentos Time
      this( time.getHour(), time.getMinute(), time.getSecond() );
   } // fim do construtor Time com um argumento de objeto Time

   // M�todos set
   // configura um novo valor de data/hora usando UTC; assegura que
   // os dados permane�am consistentes configurando valores inv�lidos como zero
   public void setTime( int h, int m, int s ) {
      setHour( h );   // configura hour
      setMinute( m ); // configura minute
      setSecond( s ); // configura second
   } // fim do m�todo setTime

   // valida e configura a hora                   
   public void setHour( int h ) {                                          
      hour = ( ( h >= 0 && h < 24 ) ? h : 0 );
   } // fim do m�todo setHour                    

   // valida e configura os minutos                   
   public void setMinute( int m ) {                                            
      minute = ( ( m >= 0 && m < 60 ) ? m : 0 );
   } // fim do m�todo setMinute                    

   // valida e configura os segundos                
   public void setSecond( int s ) {                                            
      second = ( ( s >= 0 && s < 60 ) ? s : 0 );
   } // fim do m�todo setSecond                    

   // M�todos get
   // obt�m valor da hora      
   public int getHour() {                      
      return hour;        
   } // fim do m�todo getHour

   // obt�m valor dos minutos      
   public int getMinute() {                        
      return minute;        
   } // fim do m�todo getMinute

   // obt�m valor dos segundos      
   public int getSecond() {                        
      return second;        
   } // fim do m�todo getSecond

   // converte em String no formato de data/hora universal (HH:MM:SS)
   public String toUniversalString() {
      return String.format( 
         "%02d:%02d:%02d", getHour(), getMinute(), getSecond() );
   } // fim do m�todo do toUniversalString

   // converte em String no formato padr�o de data/hora (H:MM:SS AM ou PM)
   public String toString() {
      return String.format( "%d:%02d:%02d %s", 
         ( (getHour() == 0 || getHour() == 12) ? 12 : getHour() % 12 ),
         getMinute(), getSecond(), ( getHour() < 12 ? "AM" : "PM" ) );
   } // fim do m�todo toString
} // fim da classe Time
