/* 
 * Adapta��o do fonte Sort3.java
 * Fonte: Java Como programar 6a Edi��o (Deitel & Deitel)
 * Fig. 19.11: Sort3.java 
 */
package comparador;

// Classifica uma lista utilizando a classe Comparator TimeComparator personalizada.
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class TesteTime {
   public void imprimeElementos() {
      List <Time> lista = new ArrayList <Time>(); // cria List

      lista.add( new Time(  6, 24, 34 ) );
      lista.add( new Time( 18, 14, 58 ) );
      lista.add( new Time(  6, 05, 34 ) );
      lista.add( new Time( 12, 14, 58 ) );
      lista.add( new Time(  6, 24, 22 ) );
      
      // gera sa�da de elementos List
      System.out.println( "Elementos desordenados:\n"+ lista );

      // classifica em ordem utilizando um comparador            
      Collections.sort( lista, new TimeComparator() );

      // gera sa�da de elementos List
      System.out.println( "Elementos ordenados:\n" + lista );
   } // fim do m�todo printElements 
 
   public static void main( String args[] )
   {
      TesteTime compTime = new TesteTime();
      compTime.imprimeElementos();
   } // fim de main
} // fim da classe Sort3 
