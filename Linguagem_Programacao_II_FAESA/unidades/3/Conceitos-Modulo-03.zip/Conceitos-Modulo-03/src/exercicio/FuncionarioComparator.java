package exercicio;

import java.util.Comparator;

public class FuncionarioComparator 
		implements Comparator<Funcionario> {

	@Override
	public int compare(Funcionario f1, Funcionario f2) {
		int compNome = 
		f1.getNome().compareTo(f2.getNome());
		if (compNome != 0)
			return compNome;
		
		int compCpf = 
		f1.getCpf().compareTo(f2.getCpf());
		if (compCpf != 0)
			return compCpf;
		
		return (int) (f1.getMatricula() 
				- f2.getMatricula());
	}

}
