package exercicio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TesteComparator {

	public static void main(String[] args) {
		List <Funcionario> funcs = 
				new ArrayList<Funcionario>();
		
		funcs.add(new Funcionario("Tiago", "03120766792", 123300L));
		funcs.add(new Funcionario("Rafael", "03120000233", 123300L));
		funcs.add(new Funcionario("Khammylla", "04303342343", 343333L));
		funcs.add(new Funcionario("Ludymila", "09888383833", 323223L));
		funcs.add(new Funcionario("Chico Bento", "00222112234", 244111L));
		funcs.add(new Funcionario("Frango", "00000234567", 333000L));
		funcs.add(new Funcionario("Frango", "00001234567", 333000L));
		
		System.out.println("\nFuncionarios (sem ordena��o)"+ funcs);
		Collections.sort(funcs, new FuncionarioComparator());
		
		System.out.println("\nFuncionarios (ordenados)"+ funcs);
		
	}

}
