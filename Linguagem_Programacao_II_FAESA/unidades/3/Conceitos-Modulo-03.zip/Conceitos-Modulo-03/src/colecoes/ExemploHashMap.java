package colecoes;
/* 
 * Adapta��o do fonte WordTypeCount.java
 * Fonte: Java Como programar 6a Edi��o (Deitel & Deitel)
 * Fig. 19.20: WordTypeCount.java 
 */

// Programa conta o n�mero de ocorr�ncias de cada palavra em uma string
import java.util.StringTokenizer;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.TreeSet;
import java.util.Scanner;

public class ExemploHashMap {
   private Map <String, Integer> mapa;
   private Scanner scanner;

   public ExemploHashMap()
   {
      mapa = new HashMap <String, Integer> ();// cria HashMap
      scanner = new Scanner( System.in ); // cria scanner (p/ leitura de teclado)
      criaMapa(); // cria mapa baseado na entrada de usu�rio
      exibeMapa(); // exibe conte�do do mapa 
   } // fim do construtor Atividade_09
   
   // cria mapa de entrada de usu�rio
   private void criaMapa() {
      System.out.println( "Entre com uma string:" ); // solicita a entrada de usu�rio
      String input = scanner.nextLine();

      // cria StringTokenizer para a entrada
      StringTokenizer tokenizer = new StringTokenizer( input );
               
      // processamento texto de entrada 
      while ( tokenizer.hasMoreTokens() ) // enquanto houver mais entrada
      {
         String word = tokenizer.nextToken().toLowerCase(); // obt�m palavra
                  
         // se o mapa contiver a palavra
         if (mapa.containsKey( word )) // palavra est� no mapa
         {
            int count = mapa.get( word ); // obt�m contagem atual 
            mapa.put( word, count + 1 );// incrementa a contagem de 
         } // fim do if
         else 
            mapa.put( word, 1 );// adiciona nova palavra com uma contagem de 1 ao mapa
       } // fim do while
   } // fim do m�todo createMap 
   
   // exibe conte�do do mapa 
   private void exibeMapa() 
   {      
      Set <String> chaves = mapa.keySet();// obt�m as chaves
      
      // classifica as chaves 
      TreeSet <String> chavesOrdenadas = new TreeSet <String>( chaves );

      System.out.println( "O mapa cont�m:\nKey\t\tValue" );

      // gera sa�da de cada chave no mapa
      for ( String key : chavesOrdenadas )
         System.out.printf( "%-10s%10s\n", key, mapa.get( key ));
      
      System.out.printf( 
         "\nsize:%d\nisEmpty:%b\n", mapa.size(),mapa.isEmpty());
   } // fim do m�todo displayMap

   public static void main( String args[] )
   {
      new ExemploHashMap();
   } // fim de main
} // fim da classe WordTypeCount 
