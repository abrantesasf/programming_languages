package colecoes;
/* 
 * Adapta��o do fonte SetTest.java
 * Fonte: Java Como programar 6a Edi��o (Deitel & Deitel)
 * Fig. 19.18: SetTest.java 
 */

// Utilizando um HashSet para remover duplicatas.
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ExemploHashSet {
   private static final String cores[] = { "red", "white", "blue",
      "green", "gray", "orange", "tan", "white", "cyan",
      "peach", "gray", "orange" };
                  
   // cria e gera sa�da ArrayList
   public ExemploHashSet()
   {
      List <String> lista = Arrays.asList(cores);
      Collections.sort(lista);
      System.out.println( "ArrayList: "+ lista );
      imprimeElementosNaoDuplicados( lista );
   } // fim do construtor SetTest

   // cria conjunto de array para eliminar duplicatas
   private void imprimeElementosNaoDuplicados(Collection <String> colecao) {
      // cria um HashSet (eliminando as duplicidades da List "colecao")
      Set <String> conjunto = new HashSet <String>( colecao );

      System.out.println( "\nOs elementos n�o duplicados (e n�o ordenados) s�o: " );

      System.out.println(conjunto);
//      for ( String s : conjunto )
//         System.out.print( s +  "  " );

      System.out.println();
      
//      System.out.println( "\nOs elementos n�o duplicados (e ordenados) s�o: " );
//      List <String> lista2 = new ArrayList<String>(conjunto);
//      Collections.sort(lista2);
//
//      System.out.println(lista2);
   } // fim do m�todo printNonDuplicates 

   public static void main( String args[] )
   {
      new ExemploHashSet();
   } // fim de main
} // fim da classe SetTest 
