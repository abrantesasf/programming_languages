package colecoes;
/* 
 * Adapta��o do fonte UsingArrays.java
 * Fonte: Java Como programar 6a Edi��o (Deitel & Deitel)
 * Fig. 19.2: UsingArrays.java 
 */

// Utilizando arrays Java.
import java.util.Arrays;

public class ExemploArrays { 

   private int vetorInteiros[] = { 1, 2, 3, 4, 5, 6 };
   private double vetorDoubles[] = { 8.4, 9.3, 0.2, 7.9, 3.4 };
   private int vetorInteirosPreenchido[], vetorInteirosCopiado[];

   // o construtor inicializa arrays
   public ExemploArrays() {
	   // cria o array int com 10 elementos	   
      vetorInteirosPreenchido = new int[ 10 ]; 
      vetorInteirosCopiado = new int[ vetorInteiros.length ];

      Arrays.fill( vetorInteirosPreenchido, 7 ); // preenche com 7s
      Arrays.sort( vetorDoubles); // classifica doubleArray ascendente

      // copia o array intArray no array intArrayCopy 
      System.arraycopy( vetorInteiros, 0, vetorInteirosCopiado,  
         0, vetorInteiros.length );                      
   } // fim do construtor UsingArrays

   // gera a sa�da de valores de cada array
   public void printArrays()
   {     
      System.out.print( "vetorDoubles: " );
      for ( double doubleValue : vetorDoubles )
         System.out.print( doubleValue + "  ");

      System.out.print( "\nvetorInteiros: " );
      for ( int intValue : vetorInteiros )
         System.out.print( intValue  + "  ");

      System.out.print( "\nvetorInteirosPreenchido: " );
      for ( int intValue : vetorInteirosPreenchido )
         System.out.print( intValue  + "  ");

      System.out.print( "\nvetorInteirosCopiado: " );
      for ( int intValue : vetorInteirosCopiado )
         System.out.print( intValue  + "  " );

      System.out.println( "\n" );
   } // fim do m�todo printArrays 

   // localiza valor no array intArray 
   public int procuraInteiro( int value )
   {  
      return Arrays.binarySearch( vetorInteiros, value );
   } // fim do m�todo searchForInt 

   // compara o conte�do dos arrays
   public void verificaIgualdade()
   {
      boolean b = Arrays.equals( vetorInteiros, vetorInteirosCopiado );
      System.out.print( "vetorInteiros "+ ( b ? "==" : "!=" ) + " vetorInteirosCopiado\n" );

      b = Arrays.equals( vetorInteiros, vetorInteirosPreenchido );
      System.out.printf( "vetorInteiros "+ ( b ? "==" : "!=" ) +" vetorInteirosPreenchido\n");
   } // fim do m�todo printEquality 

   public static void main( String args[] )
   {
      ExemploArrays atividade_01 = new ExemploArrays();

      atividade_01.printArrays();
      atividade_01.verificaIgualdade();

      int location = atividade_01.procuraInteiro( 5 );
      if ( location >= 0 )
         System.out.print("Elemento 5 encontrado na posi��o "+ location +" do vetorInteiros\n" ); 
      else
         System.out.println( "Elemento 5 n�o encontrado em vetorInteiros" ); 

      location = atividade_01.procuraInteiro( 100 );
      if ( location >= 0 )
          System.out.print("Elemento 100 encontrado na posi��o "+ location +" do vetorInteiros\n" ); 
      else
          System.out.println( "Elemento 100 n�o encontrado em vetorInteiros" );
      
      // compara vetores...
      System.out.println(Arrays.toString(atividade_01.vetorInteiros));
      System.out.println(Arrays.toString(atividade_01.vetorDoubles));
      System.out.println(Arrays.toString(atividade_01.vetorInteiros).equals(Arrays.toString(atividade_01.vetorDoubles)));
   } // fim de main
} // fim da classe UsingArrays 
