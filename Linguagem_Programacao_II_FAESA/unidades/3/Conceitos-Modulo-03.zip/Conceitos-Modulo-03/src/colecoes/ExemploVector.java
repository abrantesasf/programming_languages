package colecoes;
// Fig. 19.6: VectorTest.java
// Utilizando a classe Vector.
import java.util.Vector;                
import java.util.NoSuchElementException;

public class ExemploVector {
   private static final String cores[] = { "red", "white", "blue"};

   public ExemploVector() {
      Vector <String> vector = new Vector <String>();
      imprimeVector( vector , "Vetor inicial cont�m: "); // imprime vetor

      // adiciona elementos ao vetor
      for ( String cor : cores )
         vector.add( cor );

      imprimeVector( vector , "Vetor preenchido cont�m: "); // imprime vetor
      
      // gera sa�da dos primeiros e �ltimos elementos
      try 
      {
         System.out.println( "Primeiro elemento: " + vector.firstElement());
         System.out.println( "�ltimo elemento: " + vector.lastElement());
      } // fim do try
      // captura exce��o se vetor estiver vazio
      catch ( NoSuchElementException exception ) 
      {
         exception.printStackTrace();
      } // fim do catch
      
      // o vetor cont�m "red"?
      existe(vector, "red");
      
      vector.remove("red"); // remove a string "red"
      System.out.println( "\"red\" foi removido" );
      imprimeVector( vector , "Vetor cont�m: "); // imprime vetor
      
      // o vetor cont�m "red" depois da opera��o remove?
      existe(vector, "red");
      
      // imprime o tamanho e capacidade de vetor
      System.out.print( "\nTamanho: "+vector.size()+"\nCapacity: "+ vector.capacity()+"\n");
      
      String [] maisCores = {"yellow", "orange", "gray", "brown", "black", "cyan", "violet", "magenta", "olive"};
      for (String cor: maisCores){
    	  vector.add(cor);
      }

      imprimeVector( vector , "Novo vetor cont�m: "); // imprime vetor

      // imprime novamente o tamanho e capacidade de vetor
      System.out.print( "\nTamanho: "+vector.size()+"\nCapacity: "+ vector.capacity()+"\n");

   } // fim do construtor Vector
   
   private void existe(Vector <String> vect, String cor){
      if (vect.contains( cor ))
          System.out.println( "\n\""+cor+"\" encontrado no �ndice " + vect.indexOf( cor ) + "\n"); 
       else
          System.out.println( "\n\""+cor+"\" n�o encontrado" );
   }

   private void imprimeVector(Vector< String > vetor, String msg)
   {
      if (vetor.isEmpty()) 
         System.out.print( "vector est� vazio" ); // vectorToOutput est� vazio
      else  // itera pelos elementos
      {
         System.out.print( msg );      

         // envia os elementos para a sa�da
         for ( String element : vetor )
            System.out.print( element + "   ");
      } // fim de else
      
      System.out.println(); 
   } // fim do m�todo printVector 

   public static void main( String args[] )
   {
      new ExemploVector(); // cria o objeto e chama seu construtor
   } // fim de main
} // fim da classe VectorTest
