package colecoes;
/* 
 * Adapta��o do fonte SortedSetTest.java
 * Fonte: Java Como programar 6a Edi��o (Deitel & Deitel)
 * Fig. 19.19: SortedSetTest.java 
 */

// Utilizando TreeSet e SortedSet.
import java.util.Arrays;
import java.util.SortedSet;
import java.util.TreeSet;

public class ExemploTreeSet 
{
   private static final String cores[] = { "yellow", "green",
       "black", "tan", "gray", "white", "orange", "red", "green" , 
       "green" , "green" , "green" , "green" , "green" , "green" , 
       "green" , "green" , "green" , "green" , "green" , "green" };
   
   // cria um conjunto classificado com TreeSet, e depois o manipula
   public ExemploTreeSet()
   {
	   System.out.println("\nAntes de ordenar e eliminar repeti��es: \n"+
			   				Arrays.asList(cores));
      // cria TreeSet                                  
      SortedSet <String> a = new TreeSet <String>(Arrays.asList(cores));

      System.out.println( "Conjunto (Set) ordenado: " );
      imprimeConjunto( a ); // conte�do de sa�da de �rvore

      // obt�m "headSet" (o que vem antes de) com base em "orange"
      System.out.print( "\nheadSet (\"orange\"):  " );
      imprimeConjunto(a.headSet( "orange" ));

      // obt�m tailSet (o que vem depois de) baseado em "orange"
      System.out.print( "tailSet (\"orange\"):  " );
      imprimeConjunto(a.tailSet( "orange" ));
      
       // obt�m primeiro e �ltimo elementos
      System.out.println( "primeiro: "+ a.first());
      System.out.println( "�ltimo : "+ a.last());
      
   } // fim do construtor SortedSetTest

   // gera sa�da do conjunto
   private void imprimeConjunto( SortedSet <String> conjunto )
   {
      for ( String s : conjunto )
         System.out.print ( s + "  " );

      System.out.println();
   } // fim do m�todo printSet 

   public static void main( String args[] )
   {
      new ExemploTreeSet();
   } // fim de main
} // fim da classe SortedSetTest 
