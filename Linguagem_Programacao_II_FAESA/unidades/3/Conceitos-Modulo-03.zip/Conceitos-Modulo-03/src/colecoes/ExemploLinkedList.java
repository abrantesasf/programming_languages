package colecoes;
/* 
 * Adapta��o do fonte ListTest.java
 * Fonte: Java Como programar 6a Edi��o (Deitel & Deitel)
 * Fig. 19.4: ListTest.java 
 */

// Utilizando LinkLists.
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class ExemploLinkedList {
   private static final String vetCores1[] = { "black", "yellow", 
      "green", "blue", "violet", "silver" };
   private static final String vetCores2[] = { "gold", "white", 
      "brown", "blue", "gray", "silver" };
                  
   // configura e manipula objetos LinkedList
   public ExemploLinkedList() {
//      List <String> lista1 = new LinkedList <String>(Arrays.asList(vetCores1)); 
	  List <String> lista1 = new LinkedList <String>(); 
      List <String> lista2 = new LinkedList <String>();

      // adiciona elementos a list1
      for ( String cor : vetCores1 )
        lista1.add( cor );

      // adiciona elementos a list2
      for ( String cor : vetCores2 )
         lista2.add( cor );

      lista1.addAll( lista2 ); // concatena as listas
      lista2 = null; // libera recursos
      imprimeLista( lista1 ); // imprime elementos list1 

      converteListaDeStringsParaMaiusculas( lista1 ); // converte a string em letras mai�sculas 
      imprimeLista( lista1 ); // imprime elementos list1 

      System.out.print( "\nExclindo elementos de 3 at� 5..." );
      removeItens( lista1, 3, 5 ); // remove itens 3-5 da lista
      imprimeLista( lista1 ); // imprime elementos list1 
      imprimeListaOrdemInversa( lista1 ); // imprime lista na ordem inversa
   } // fim do construtor ListTest

   // gera sa�da do conte�do de List
   public void imprimeLista(List <String> lista) {
      System.out.println( "\nlista: " );
      int cont = 1;
      for ( String cor : lista )
         System.out.print("("+ cont++ +")" + cor + "   " );

      System.out.println();
   } // fim do m�todo printList 

   // localiza objetos String e converte em letras mai�sculas
   private void converteListaDeStringsParaMaiusculas(List <String> lista) {
      ListIterator <String> iterador = lista.listIterator();

      while (iterador.hasNext()) {
         String cor = iterador.next();  // obt�m o item
         iterador.set( cor.toUpperCase() ); // converte em letras mai�sculas 
      } // fim do while
   } // fim do m�todo convertToUppercaseStrings 

   // obt�m sublista e utiliza m�todo clear para excluir itens da sublista
   private void removeItens(List <String> lista, int inicio, int fim ) {
      lista.subList( inicio, fim ).clear();  // remove os itens
   } // fim do m�todo removeItems

   // imprime lista invertida
   private void imprimeListaOrdemInversa(List <String> lista)
   {
      ListIterator <String> iterador = lista.listIterator( lista.size() );

      System.out.println( "\nLista invertida:" );
      int cont = lista.size();
      // imprime lista na ordem inversa
      while (iterador.hasPrevious()) 
         System.out.print ("("+ cont-- +")"+ iterador.previous() + "   "); 
   } // fim do m�todo printReversedList
   
   public static void main( String args[] )
   {
      new ExemploLinkedList();
   } // fim de main                                          
} // fim da classe ListTest

