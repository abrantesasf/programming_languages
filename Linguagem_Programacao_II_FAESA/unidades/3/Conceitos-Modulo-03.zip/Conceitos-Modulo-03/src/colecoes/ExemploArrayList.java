package colecoes;
/* 
 * Adapta��o do fonte UsingArrays.java
 * Fonte: Java Como programar 6a Edi��o (Deitel & Deitel)
 * Fig. 19.3: CollectionTest.java
 */
// Utilizando a interface Collection.

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ExemploArrayList {
   private static final String[] cores = 
      { "VERMELHO", "VERDE", "AZUL", "PURPURA", "CIANO", "ROXO", "ROSA", "LARANJA" };
   private static final String[] removerCores = 
      { "VERMELHO", "BRANCO", "AZUL", "ROXO" };

   // cria ArrayList, adiciona cores a ela e a manipula
   public ExemploArrayList()
   {
      List <String> listaDeCores = new ArrayList <String>();      
      List <String> listaDeCoresARemover = new ArrayList <String>();

      // adiciona elementos do array "cores" na lista listaDeCores
      for ( String cor : cores )
         listaDeCores.add( cor );

      // adiciona elementos do array "removerCores" na lista listaDeCoresARemover
      for ( String cor : removerCores )
         listaDeCoresARemover.add( cor );


      // gera sa�da do conte�do da lista
//      for ( int count = 0; count < listaDeCores.size(); count++ ){
//          System.out.print(listaDeCores.get( count ) + "   ");
//      }

      System.out.println( "ArrayList lista de cores: " );
      System.out.println(listaDeCores.toString());
      
      System.out.println( "\nArrayList lista de cores a REMOVER: " );
      System.out.println(listaDeCoresARemover.toString());
      
      // remove cores de listaDeCores e que est�o em listaDeCoresARemover
      removeCores( listaDeCores, listaDeCoresARemover );

      System.out.println( "\n\nArrayList depois da chamada a removeCores: " );

      // gera sa�da do conte�do da lista
      for ( String cor : listaDeCores )
         System.out.print( cor + "   " );
   } // fim do construtor CollectionTest

   // remove de colecao1 as cores especificadas em colecao2 
   private void removeCores( List <String> colecao1, 
		   					 List <String> colecao2)
   {
      // obt�m o iterador da collection1
      Iterator <String> iterator = colecao1.iterator(); 

      // loop enquanto a cole��o tiver itens
      while (iterator.hasNext()) {
          if (colecao2.contains( iterator.next() ))
              iterator.remove();// remove Color atual
      }
   } // fim do m�todo removeCores 

   public static void main( String args[] )
   {
      new ExemploArrayList();
   } // fim de main
} // fim da classe CollectionTest 

