package colecoes;
/* 
 * Adapta��o do fonte Sort1.java
 * Fonte: Java Como programar 6a Edi��o (Deitel & Deitel)
 * Fig. 19.8: Sort1.java 
 */

// Utilizando o algoritmo sort.
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ExemploOrdenacao {
   private static final String cores[] = 
   { "black", "yellow", "green", "blue", "violet", "silver" };

   // exibe elementos da lista
   public void imprimeElementos(){
	   // 	cria List
      List <String> lista = Arrays.asList( cores ); 
      System.out.println( "Exibe elementos n�o ordenados:\n" + lista + "\n");

      // ordena lista 
      Collections.sort( lista ); 
      System.out.println( "Exibe elementos ordenados:\n" + lista+ "\n");
      
      // "embaralha" lista
      Collections.shuffle(lista);
      System.out.println( "Exibe elementos \"embaralhados\":\n" + lista+ "\n");
      
      // ordena lista em ordem decrescente
      Collections.sort( lista, Collections.reverseOrder() ); // classifica ArrayList 
      System.out.println( "Exibe elementos ordenados decrescente:\n" + lista+ "\n");
   } // fim do m�todo printElements 

   public static void main( String args[] ){
      ExemploOrdenacao sort1 = new ExemploOrdenacao();
      sort1.imprimeElementos();
   } // fim de main
} // fim da classe Sort1 
